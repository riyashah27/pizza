import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PizzaAddComponent } from './pizza-app/pizza-add/pizza-add.component';
import { PizzaEditComponent } from './pizza-app/pizza-edit/pizza-edit.component';
import { PizzaDeleteComponent } from './pizza-app/pizza-delete/pizza-delete.component';
import { PizzaGetComponent } from './pizza-app/pizza-get/pizza-get.component';

const routes: Routes = [
  {path:'cart',component:PizzaAddComponent},
  {path:'pizza', component:PizzaGetComponent},
  {path:'pizza/delete/:orderId',component:PizzaDeleteComponent},
  {path:'pizza/edit/:orderId',component:PizzaEditComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
