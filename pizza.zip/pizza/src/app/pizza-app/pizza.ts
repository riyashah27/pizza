export class Pizza
{
    _id?:number;
    orderName:string;
    price:number;
    pizzaType:string;
    _v?:number;
}