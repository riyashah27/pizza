import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';


import { Pizza } from './pizza';


@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  pizzas=[];
  constructor(private httpClient:HttpClient) { }

  uri='http://localhost:4000/pizza'; 


  getOrders():Observable<Pizza[]>{
    return this.httpClient.get<Pizza[]>(`${this.uri}`+'/allOrder');
  }

 
  // addOrder(id,name,price)
  // {
  //   let pizza={
  //     orderId:id,
  //     orderName:name,
  //     price:price
  //   };
  //   return this.httpClient.post(`${this.uri}`+'/addOrder',pizza).subscribe(res=>console.log("New Order Added Successfully"));
  // }

    public addToCart(pizza)
    {
      this.pizzas.push(pizza);
    }
    getCartPizzas()
    {
      return this.pizzas;
    }

  deleteOrder(orderId:number):any
  {
    this.httpClient.delete(`${this.uri}`+'/delete/'+`${orderId}`).subscribe(res=>console.log("Order Cancelled Successfully"));
  }

  // updateOrder(orderId,price):any{

  //   return this.httpClient.put(`${this.uri}`+'/update/'+orderId+'/'+price,{}).subscribe(res => console.log('Done'));
  // }
}