import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PizzaAddComponent } from './pizza-app/pizza-add/pizza-add.component';
import { PizzaDeleteComponent } from './pizza-app/pizza-delete/pizza-delete.component';
import { PizzaEditComponent } from './pizza-app/pizza-edit/pizza-edit.component';
import { PizzaGetComponent } from './pizza-app/pizza-get/pizza-get.component';
import { TopBarComponent } from './pizza-app/top-bar/top-bar.component';



@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  declarations: [
    AppComponent,
    PizzaAddComponent,
    PizzaDeleteComponent,
    PizzaEditComponent,
    PizzaGetComponent,
    TopBarComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }