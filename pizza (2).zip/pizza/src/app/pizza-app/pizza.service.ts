import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable,of } from 'rxjs';


import { Pizza } from './pizza';


@Injectable({
  providedIn: 'root'
})
export class PizzaService {
  pizzas=[];
  pizza:Pizza[]=[];
  constructor(private httpClient:HttpClient) { }

  uri='http://localhost:4000/pizza'; 


  getOrders():Observable<Pizza[]>{
    return this.httpClient.get<Pizza[]>(`${this.uri}`+'/allOrder');
  }   public addToCart(pizza)
    {
      this.pizzas.push(pizza);
    }
    getCartPizzas()
    {
      return this.pizzas;
    }
  public getitems():Observable<Pizza[]>
  {
      return of(this.pizzas);
  }

  deleteFromCart(orderName){
    this.pizzas.pop();
}
}